<?php 
	 //LOGIC NONSENSE
	 
	// print_r($_POST);

	 // TEST FOR ERROR CONDITIONS	
	 
	
	 
	
	 // 1. test for error conditions
	 
	 $name = $_POST["fname"];
	 $email = $_POST["email"];
	 $cc = $_POST["cc"];
	 
	 //check if fields are blank
	 
	 if(empty($name) || empty($email) || empty($cc)) {
		echo "Name,email or cc is blank <br>"; 
	 }
	 //check if credit card is valid
	  if(strlen($_POST["cc"]) !=16) {
echo "Credit card number should be 16 digits! <br>";
	 };
	 
	 if (ccIsValid($cc) == false) {
		 //echo "Credit card is INVALID! <br>";
		 
	 }
	 // 2. check if credit card is valid
	 //  2a) check if the cc is 16 digits
	 //	 2b) does cc pass the algorithm 	
	 
	 // if all conditions pass, then SHOW SUCCESS MESSAGE

	 
	 //function 
	 
	 function ccIsValid($cc) {
		 if (strlen($cc) == 16) {
	// 0. reverse the cc number so all the \
	// positions match the algorithm
	
	$reversed = strrev($cc);
	// echo "Reversed: " . $reversed . "<br>";
	// 1. loop through the numbers in the cc
	$total = 0;
	for ($i=0;$i<16;$i++) {
		// @debug: print out each character
		// echo $reversed[$i] . "<br>";
		
		
	
	// 2. if position = odd,
	// 2a) multiply by 2
	// 2b) if multiply  > 9, then convert
	if ($i % 2 == 1) {
		//do multiply + convert
		$num = $reversed[$i] * 2;
		// echo "== Multiply: " . $num . "<br>";
		if($num > 9) {
			$num = $num - 9;
		}
	}
	else {
		// do nothng
		$num = $reversed[$i];
	}
	// otherwise, do nothing 
	
	// 3. add to the total!
	$total = $total + $num; 

	} //end of loop
		// 4. after looping 
	if ($total % 10 == 0 ) {
		
			echo "Your credit card is valid ! <br>";
		}
	else {
echo "Your credit card is invalid ! <br>";
	}	
}
	 }
?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
        Hello World
      </h1>
      <a href="checkout.php" > Go Back </a>
    </div>
  </section>
  </body>
</html>