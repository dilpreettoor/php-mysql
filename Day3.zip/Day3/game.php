<?php
 $file = file_get_contents("simplewords.txt",true);
 $words = str_word_count($file,1);
 //print_r(array_rand($words));
 
 $length = count($words);
 $picked = [];
 $choices = [];
 for ($i=0; $i < 10; $i++) {
	 //pick a random number
	 $randomNumber = rand ( 0 , $length-1);
	 
	 //check if random num already picked
	 
	 if(in_array($randomNumber, $picked) == true) {
		 //skip
		 continue;
	 }
	 else {
		 array_push($choices, $words[$randomNumber]);
		break;
	 
	 
 }
 print_r($choices);
 }
 
 ?>