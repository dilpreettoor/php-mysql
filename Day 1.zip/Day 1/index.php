
<h2> php basics </h2>

<?php 
// your code goes here

$x = 25;
$y = "jenelle";
$z = 30.9;
$djfsdfdfsdfsdf = $x + $x;

//output to the screen

//console.log(....)

//echo "HELLO WORLD! \n";
echo $x;
echo "<h2 style= color:red> dddd </h2> ";

//output to the screen
echo "hello" . "goodbye" . "timmies" . "donut";
echo "<br>"; 
echo $x + $z;
echo "<br>";

// if statements
$abc = 30;
if ($abc > 25) {
	echo "HELLO";
}
else if($abc < 25) {
	echo "APPLE";
}
else {
	echo "GOODBYE";
}

echo "<br>";


//for-loop -> while loop>
//for-loop
// -loop that repeats a fixed number of times
// - you tell the loop how many times you wanan loop
//while
// - loop that repears until a condition is met 
// - doesn't stop until a condition is met

for($i = 0; $i < 5; $i++) {
	echo "HELLO! <br>";
}

//while loop
$b = 5;
while ($b<8) {
	echo "BYE! <b5>";
	$b = $b + 1;
}

function sayHello() {
	echo "ABACAXI <br>";
	echo "ANANAS <br>";
	echo "PINEAPPLE <br>";
}

function fruit($lang) {
	echo "ANANAS";
}

function pineapple($lang) {
	if ($lang == "gujarati") {
		echo "ANANAS";
	}
	else if ($lang == "malayalam") {
		echo "KAITHACHAKA";
	}
	else if ($lang == "br"){
		echo "ABACAXI";
	}
	else if ($lang == "viet"){
		echo "DUA";
	}
	else {
		sayHello();
	}
}

//USING A FUNCTION 

pineapple("english");

// ARRAYS

// create empty arrays
$animals = [];
$animals = array();

// add thing to the array
$animals[0] = "dog";
$animals[1] = "cat";

//another way to add to array
array_push($animals, "fox");

for($j=5; $j < 10; $j++) {
	array_push($animals, "cow");
}

// length of the array
echo "The length of the rray is: " . count($animals);

for ($j = 0; $j < count($animals); $j++) {
	echo "Hello : " . $animals[$j] . "<br>";
}

//shiyard -> raposa

//command for outputting arrays to the screen
print_r($animals);

//to clear an array - $animals = [];


// ASSOCIATIVE ARRAY 

$easy = array(
"en" => "easy",
"fr" => "facile",
"vt" => "de",
"br" => "facil",
"pu" => "sokha",
"gu" => "saral",
"my" => "elupam"
);
echo "<br>";
print_r($easy);
//single item from dictionary
echo $easy["my"] . "<br>";

//looping through an associate array 
foreach($easy as $abc => $fff) {
	echo "Key is: " . $abc . "<br>";
	echo "Value is: " . $fff . "<br>";
	echo "=======" . "<br>";
}