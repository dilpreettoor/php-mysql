
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Shop Pop!</title>
    <link href="index.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link href="css/bulma.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
      nav {
        margin-top:40px;
      }
    </style>
  </head>
  <body>

   <nav class="level">
      <p class="level-item has-text-centered">
        <a class="link is-info">About Us</a>
      </p>
      <p class="level-item has-text-centered">
        <a class="link is-info">Location</a>
      </p>
      <p class="level-item has-text-centered">
	  <img src="images/logo.png">
      </p>
      <p class="level-item has-text-centered">
        <a class="link is-info">Menu</a>
      </p>
      <p class="level-item has-text-centered">
      </p>
    </nav>
	
	
  </body>
</html>