<h1> Hello! </h1>
<h2> This is the next page! </h2>

<?php

/*build a simple program to check if the person came to this using a GET or POST request */
if($_SERVER["REQUEST_METHOD"] == "POST") {
	//post
	echo "You came with aPOST";
}
else if ($_SERVER["REQUEST_METHOD"] == "GET") {
	echo "You came with a GET";
}
// how do i get tge stuff
// that was sent in the form?

echo "<br>  Whats in the get? <br>";
print_r($_GET);

echo "<br>  Whats in the post? <br>";
print_r($_POST);

echo " The student is: " . $_GET["name"]. "<br>";

?>