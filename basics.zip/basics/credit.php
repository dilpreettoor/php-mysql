<p> check credit card! </p>

<?php

// check if cc is 16 digits long
$cc = "4685631458814460";

//if 16 digits, awesome
if (strlen($cc) == 16) {
	// 0. reverse the cc number so all the \
	// positions match the algorithm
	
	$reversed = strrev($cc);
	echo "Reversed: " . $reversed . "<br>";
	// 1. loop through the numbers in the cc
	$total = 0;
	for ($i=0;$i<16;$i++) {
		// @debug: print out each character
		echo $reversed[$i] . "<br>";
		
		
	
	// 2. if position = odd,
	// 2a) multiply by 2
	// 2b) if multiply  > 9, then convert
	if ($i % 2 == 1) {
		//do multiply + convert
		$num = $reversed[$i] * 2;
		echo "== Multiply: " . $num . "<br>";
		if($num > 9) {
			$num = $num - 9;
		}
	}
	else {
		// do nothng
		$num = $reversed[$i];
	}
	// otherwise, do nothing 
	
	// 3. add to the total!
	$total = $total + $num; 

	} //end of loop
		// 4. after looping 
	if ($total % 10 == 0 ) {
		
			echo "Your credit card is valid ! <br>";
		}
	else {
echo "Your credit card is invalid ! <br>";
	}	
}

?>