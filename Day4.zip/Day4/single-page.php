<?php
//start a session

session_start();


	if ($_SERVER["REQUEST_METHOD"] == "GET" ) {
		//echo "creating a new game! <br>";
		
		$SESSION["password"] = "HELLO";
		echo "Creating a new game! <br>";
		echo "password: " . $password;
	}
	else if ($_SERVER["REQUEST_METHOD"] == "POST") {
		echo "Your guess is: " . $_POST["guess"];
		echo "<br>This is wrong! ";
		$SESSION["password"] = "HELLO";
		echo "your password: " . $_SESSION["password"] . "<br>";
	}
	
?>
<html>
<head>
	<title> Single page refresh! </title>
</head>
<body>

	<br>
	
	<form method="POST" action="single-page.php">
		What's your guess? 
		<input type = "text" name="guess" placeholder="enter guess">
		<button type="submit">Submit </button>
	</form>
	
	<a href="single-page.php">Create a new game </a>
</body>
</html>