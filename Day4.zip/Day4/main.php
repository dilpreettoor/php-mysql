<?php
	session_start();
		
	define("TOTAL_WORDS", 10);
	
	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		 // -------- lets do max attempts!
		$_SESSION["attempts"] = 4;
		
		// --------- generate new words
		
		echo "Create a new game - generate random word <br>";
		
		// read words from a file and put in array
		$file = file_get_contents("simplewords.txt", true);
		$words = str_word_count($file, 1);
		
		// get lenght of array
		$length = count($words);
		
		// pick 10 random random word
		$positions = array_rand($words, TOTAL_WORDS);
		$choices = [];
		for ($i = 0; $i < count($positions); $i++) {
		  $x = $positions[$i];
		  array_push($choices, $words[$x]);
		}	
		
		
		// store the random words into a session variable
		$_SESSION["choices"] = $choices;
		
		
		// pick a random word to be a password!
		// OPTION 1: $x = rand(0, count($choices)-1);
		// OPTION 2: $x = rand(0, 10);
		$x = rand(0, count($choices)-1);
		
		$password = $choices[$x];
		$_SESSION["password"] = $password;
		
		// print out the words choices
		for ($j=0; $j < count($choices); $j++) {
			echo $choices[$j] . "<br>";
		}
		
		echo "random password: ".  $password ."<br>";
	}
	else if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
		// @UI NONSENSE: print out the list of possible words 
		// for user to pick from
		$choices = $_SESSION["choices"];
		echo "<ul>";
		for ($i = 0; $i < count($choices); $i++) {
			echo "<li>";
			echo $choices[$i] . "<br>";
			echo "</li>";
		
		}
		echo "</ul>";
			
		
		echo "=============<br>";
		
		$password = $_SESSION["password"];
		
		// 1. get the word from the UI
		$guess = $_POST["guess"];
		echo $guess . "<br>";
		
		// 2. Compare the guess to the password;
		if ($guess == $password) {
			// correct
			echo "WINNER!";
		}
		else {

			if ($_SESSION["attempts"] == 0) {
				echo "Game over! <br>";
			}
			else {
				// wrong
							
				$correct = 0;
				for ($i = 0; $i < 4; $i++) {
					if ($guess[$i] == $password[$i]) {
						$correct = $correct + 1;
					}
				}
				echo "Number of correct letters: " . $correct . "<br>";

				$_SESSION["attempts"] = $_SESSION["attempts"] - 1;
				echo "You have: " . $_SESSION["attempts"] . " left <br>";	
			}
		}
	}




	
?>



<html>
<head>
<!--link rel="stylesheet" type="text/css" href="css/skeleton.css"-->
</head>
<body>

<br>

<form action="main.php" method="POST">
	<label> Enter a word: </label>
	<input name="guess" type="text">
	<button type="submit">Go!</button>
</form>

<br>

<a href="main.php"> Start a new game </a>

</body>
</html>



