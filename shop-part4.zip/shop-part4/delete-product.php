<?php
	
	$id = $_GET["id"];

	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	
	$query = "SELECT * from product where id=" . $id;
	
	$results = mysqli_query($conn, $query);
	
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$name = $_POST['name'];
		$desc = $_POST["product_desc"];
		$price = $_POST["price"];

		if(empty($name) || empty($desc) || empty($price))
		{
				$message = "Kindly fill all the mandatory fields";
				echo "$message";		
		}
		else
		{
			$query = 'UPDATE product SET name = "'.$name.'", product_desc = "'.$desc.'", price ="'.$price.'" WHERE id='.$id;
		
			$results = mysqli_query($conn, $query);
		
				if ($results) 
				{
					header("Location:show-products.php");
				}
				else 
				{
					$message = mysqli_error($conn);
					echo "<script type='text/javascript'>alert('$message');</script>";
				}

		}
	}
	
?>
<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	<style type="text/css">
		.mdl-grid {
			max-width:1024px;
			margin-top:40px;
		}
		
		h1 {
			font-size:36px;
			text-align: center;
		}
		h2 {
			font-size:30px;
		}
	</style>

</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
	  	<h1> Delete Product </h1>
		<h2> Are you sure you want to delete ?: </h2>

		<!-- form -->
		<!-- @TODO: Update your form action/method here -->
		<form action="#" method="POST">
			<?php
			while( $product = mysqli_fetch_assoc($results) ) 
			{
				echo "<div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>";
					echo "<label>".$product["name"]."</label>";
				echo "</div>";
				echo "<br>";
				echo "<div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>";
					echo "<label>".$product["product_desc"]."</label>";
				echo "</div>";
				echo "<br>";
				echo "<div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>";
					echo "<label>".$product["price"]."</label>";
				echo "</div>";
				echo "<br>";
			}
			?>
			<br>
				  
		  <!-- @TODO: Update the link  -->
		  <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent">
			Delete
		  </button>
		</form>
		
		<br>
		
		<a href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			< Go Back 
		</a>
	  </div>
	</div>
	
</body>
</html>