<h1> Connecting to a Database </h1>

<?php
// write the code to connect to the dba_close


// 1. what is your database information?
//      dn name? db password? db user?
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = ""; //on MAMP, this is root
$dbname = "madt3134";

// 2. Connect to the database
$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

// 3. DO/MAKE a SQL QUERY
$query = "SELECT * from employeeS";

// 4. SEND QUERY & GET RESULTS FROM DATABASE
$results = mysqli_query($conn, $query);

// 5. SHOW THE DATABASE RESULTS SOMEWHERE 
//var_dump($results);




//loop through the database results
while( $employees = mysqli_fetch_assoc($results) ) 
{ //use while bcuz it is more ROBUST
	//print_r($employees);
	echo "<a href='#'> <span style='color:red'>";
	echo $employees["firstname"];
	echo "</span></a>";
	echo "<br>";
}

// 6. DISCONNECT FROM DATABASE
mysqli_free_result($results); //clean up your row variable
mysqli_close($conn); // close connection to db


?>
